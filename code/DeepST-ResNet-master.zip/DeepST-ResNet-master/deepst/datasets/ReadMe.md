## Beijing

Beijing.py is an unified interface to load data 